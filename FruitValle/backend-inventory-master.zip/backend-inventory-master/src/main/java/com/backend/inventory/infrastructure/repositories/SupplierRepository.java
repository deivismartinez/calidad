package com.backend.inventory.infrastructure.repositories;

import com.backend.inventory.infrastructure.entities.Supplier;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface SupplierRepository extends JpaRepository<Supplier, Long> {
    Page<Supplier> findAllByStatus(boolean status, Pageable pageable);
}
