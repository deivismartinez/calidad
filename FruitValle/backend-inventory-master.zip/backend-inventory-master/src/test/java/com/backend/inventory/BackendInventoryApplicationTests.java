package com.backend.inventory;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendInventoryApplicationTests {

	@Test
	void contextLoads() {
	}

}
