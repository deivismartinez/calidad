﻿namespace ReservaHotel.Domain.Entities;

public class DomainEntity
{
    public Guid Id { get; set; }
}
