﻿namespace ReservaHotel.Domain.Services;

[AttributeUsage(AttributeTargets.Class)]
public sealed class DomainServiceAttribute : Attribute
{
}
