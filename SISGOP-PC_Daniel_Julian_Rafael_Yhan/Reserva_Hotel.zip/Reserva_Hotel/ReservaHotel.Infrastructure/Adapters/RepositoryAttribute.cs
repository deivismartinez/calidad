﻿namespace ReservaHotel.Infrastructure.Adapters
{
    [AttributeUsage(AttributeTargets.Class)]
    public sealed class RepositoryAttribute : Attribute
    {
    }
}
